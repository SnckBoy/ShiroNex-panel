# ShiroNex Final Package — 2026-08-25

This package is an edited build of the uploaded ShiroNex source.

## Changes made in this package
- Hardened the server CPU/RAM/Disk resource dial calculations against NaN/Infinity and out-of-range values.
- Resource panel label changed from `Telemetry & Usages` to `Live Resource Usage`.
- Added safe polling behavior for the compact live RAM component.
- URL-encoded Modrinth and Spiget plugin searches so spaces/special characters do not break search requests.
- Preserved the existing real Docker/Node-daemon architecture and security boundaries.
- Preserved existing installer, Node Agent, authentication and RBAC code.

## Important verification note
This environment did not have a reliable completed dependency installation/build run within the available execution window, so this archive must not be represented as universally bug-free or as tested against a live VPS.

Before production deployment, run:
- `npm ci`
- `npm run lint`
- `npm run build`
- `cd node-daemon && npm ci && npm run build`

Then test with a real Docker-enabled Ubuntu/Debian VPS.

## Architecture
Panel -> authenticated Node Agent -> Docker Engine -> Minecraft container.

Do not expose Docker socket directly to the public browser.
