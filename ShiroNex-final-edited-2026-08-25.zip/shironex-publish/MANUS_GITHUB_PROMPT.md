# Manus 1.6 Lite Prompt — Add the ShiroNex Final Package to GitHub

You are modifying my existing GitHub repository:

https://github.com/SnckBoy/ShiroNex-panel

I have provided an updated ShiroNex source ZIP. Use the ZIP as the source for the requested update.

IMPORTANT:
- Do not delete working features.
- Do not replace the project with a demo.
- Do not commit node_modules, secrets, production credentials, .env files, private keys, or build caches.
- Preserve the existing Node Agent + Docker architecture.
- Preserve authentication and RBAC.
- Inspect the repository before changing files.
- Compare the uploaded package with the repository and merge the improvements safely.

TASK:

1. Extract the uploaded ShiroNex source package.
2. Compare it with the current repository.
3. Apply the updated files to the repository.
4. Keep any repository changes that are newer and still compatible.
5. Do not overwrite unrelated improvements blindly.
6. Ensure the repository contains:
   - frontend
   - backend
   - node-daemon
   - install.sh
   - node-install.sh
   - Docker integration
   - authentication
   - RBAC
   - server management
   - Node management
   - plugin/modpack systems
   - player manager
   - file manager
   - backups
   - HTTPS/SSL support
   - documentation

UI/UX REQUIREMENTS:

- Keep ShiroNex branding.
- Use Midnight Violet / Royal Purple / Electric Indigo / Cyber Blue.
- Keep animations smooth and lightweight.
- Keep mobile support using 100dvh and safe-area insets.
- Keep minimum 44px touch targets.
- Do not introduce animation that causes lag.
- Keep the 3D/Three.js background lazy-loaded.

FUNCTIONAL REQUIREMENTS:

- Do not fake Docker state.
- Do not fake Node heartbeat.
- Do not use random resource values.
- Server CPU/RAM/Disk values must come from the real backend/node/container telemetry.
- Node status must be based on authenticated heartbeat.
- Local Node must use the ShiroNex Node Agent.
- Remote Node must use the ShiroNex Node Agent.
- Docker operations must execute through the backend/Node Agent.
- Console commands must reach the actual Minecraft container.
- Plugin searches must work with real provider APIs.
- Modpack searches/installations must use real provider APIs.
- RBAC must be enforced server-side.

NODE SYSTEM:

Keep:
Panel -> Node Agent -> Docker -> Minecraft Container.

Do not expose /var/run/docker.sock directly to the browser.

INSTALLER:

Preserve and improve:

curl -fsSL https://raw.githubusercontent.com/SnckBoy/ShiroNex-panel/main/install.sh | sudo bash

The installer must remain interactive and must support:

1 Panel
2 Local Node
3 Remote Node
4 Panel + Node
5 HTTPS/SSL
6 Update
7 Repair
8 Diagnostics
9 Uninstall
10 System Information
11 User management
0 Exit

Before committing:

Run:
npm ci
npm run lint
npm run build

Then:
cd node-daemon
npm ci
npm run build

Fix any build/type errors caused by the merge.

Do not claim live Docker/node functionality was tested unless a real Docker-enabled VPS was available.

After verification:

1. Show `git diff --stat`.
2. Show important changed files.
3. Commit the changes with a clear commit message such as:

"Upgrade ShiroNex UI and harden live resource monitoring"

4. Push the changes to:

SnckBoy/ShiroNex-panel

5. Confirm the final commit SHA and branch.

Do not create a new unrelated repository.
Do not remove existing Git history.
