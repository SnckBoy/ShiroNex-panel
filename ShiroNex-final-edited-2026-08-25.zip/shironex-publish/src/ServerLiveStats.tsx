import { useState, useEffect } from "react";
import axios from "axios";

export default function ServerLiveStats({ serverId, limitRam, status }: { serverId: string, limitRam: number, status: string }) {
  const [liveRam, setLiveRam] = useState<number | null>(null);

  useEffect(() => {
    if (status !== 'online') return;
    let alive = true;
    const fetchStats = async () => {
      try {
        const res = await axios.get(`/api/servers/${serverId}/stats`, { timeout: 8000 });
        const value = Number(res.data?.ram);
        if (alive && Number.isFinite(value) && value >= 0) setLiveRam(value); // RAM is in MB
      } catch(e) {}
    };
    fetchStats();
    const interval = setInterval(fetchStats, 5000);
    return () => {
      alive = false;
      clearInterval(interval);
    };
  }, [serverId, status]);

  if (status !== 'online') {
    return <span className="font-mono text-foreground-muted text-xs md:text-sm">{limitRam} <span className="text-muted-foreground">GB</span></span>;
  }

  const liveRamGB = liveRam !== null ? (liveRam / 1024).toFixed(1) : "...";

  return (
    <span className="font-mono text-foreground-muted text-xs md:text-sm">
      {liveRamGB} <span className="text-muted-foreground">/ {limitRam} GB</span>
    </span>
  );
}
