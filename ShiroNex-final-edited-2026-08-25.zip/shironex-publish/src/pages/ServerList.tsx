// @ts-nocheck
// ╔══════════════════════════════════════════════════════════════════════════╗
// ║  ServerList · Fleet grid with live status and per-server metrics           ║
// ║                                                                            ║
// ║  STEP 1 · Imports          STEP 5 · Primitives (StatusBadge, Metric)       ║
// ║  STEP 2 · Types            STEP 6 · ServerCard                             ║
// ║  STEP 3 · Constants        STEP 7 · Sections (Loading, Empty)             ║
// ║  STEP 4 · Data hook        STEP 8 · Page composition                       ║
// ╚══════════════════════════════════════════════════════════════════════════╝

/* ── STEP 1 · Imports ─────────────────────────────────────────────────────── */
import {
  memo,
  useCallback,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from "react";
import axios from "axios";
import { Link } from "react-router-dom";
import { Server, Plus, ChevronRight, Settings, Lock } from "lucide-react";
import { motion, type Variants } from "framer-motion";
import { useAuth } from "../context/AuthContext";
import ServerLiveStats from "../components/ServerLiveStats";

/* ── STEP 2 · Types ───────────────────────────────────────────────────────── */
type ServerStatus = "online" | "offline" | (string & {});

interface ServerRecord {
  id: string;
  name: string;
  status: ServerStatus;
  cpu?: number;
  ram?: number;
  disk?: number;
  version?: string;
  software?: string;
  owner?: string;
  ownerUsername?: string;
  nodeId?: string;
  nodeName?: string;
  nodeStatus?: string | null;
  address?: string;
  lastActivity?: string | null;
  playersOnline?: number | null;
  playersMax?: number | null;
  suspended?: boolean;
}

interface ServersState {
  servers: ServerRecord[];
  error: string | null;
  isLoading: boolean;
}

/* ── STEP 3 · Constants ───────────────────────────────────────────────────── */
const EASE = [0.22, 1, 0.36, 1] as const;
const POLL_INTERVAL_MS = 5_000;
const SURFACE = "transparent"; // Changed to transparent so global background shows

const containerVariants: Variants = {
  hidden: { opacity: 0 },
  show: {
    opacity: 1,
    transition: { staggerChildren: 0.05, delayChildren: 0.03 },
  },
};

const itemVariants: Variants = {
  hidden: { opacity: 0, y: 12 },
  show: { opacity: 1, y: 0, transition: { duration: 0.35, ease: EASE } },
};

const isOnline = (status?: ServerStatus): boolean => status === "online";

/* ── STEP 4 · Data hook (fetch + poll) ────────────────────────────────────── */
/** Fetches the server fleet and re-polls on a fixed interval with cleanup. */
function useServers(pollIntervalMs = POLL_INTERVAL_MS): ServersState {
  const [servers, setServers] = useState<ServerRecord[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  const fetchServers = useCallback(async (signal?: AbortSignal) => {
    try {
      const res = await axios.get<ServerRecord[]>("/api/servers", { signal });
      setServers(Array.isArray(res.data) ? res.data : []);
      setError(null);
    } catch (err) {
      if (axios.isCancel(err)) return;
      setError("Unable to load servers. Retrying…");
      console.error("Failed to fetch servers:", err);
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    const controller = new AbortController();
    void fetchServers(controller.signal);
    const interval = window.setInterval(
      () => void fetchServers(controller.signal),
      pollIntervalMs,
    );
    return () => {
      controller.abort();
      window.clearInterval(interval);
    };
  }, [fetchServers, pollIntervalMs]);

  return { servers, error, isLoading };
}

/* ── STEP 5 · Primitives ──────────────────────────────────────────────────── */
const StatusBadge = memo(function StatusBadge({
  status,
}: {
  status?: ServerStatus;
}) {
  const online = isOnline(status);
  return (
    <span
      className={`inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-[11px] font-medium uppercase tracking-wide ${
        online
          ? "bg-emerald-500/10 text-emerald-400 ring-1 ring-inset ring-emerald-500/20"
          : "bg-muted text-muted-foreground ring-1 ring-inset ring-border"
      }`}
    >
      <span className="relative flex h-1.5 w-1.5">
        {online && (
          <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-400/80 motion-reduce:hidden" />
        )}
        <span
          className={`relative inline-flex h-1.5 w-1.5 rounded-full ${
            online ? "bg-emerald-400" : "bg-zinc-500"
          }`}
        />
      </span>
      {online ? "Online" : "Offline"}
    </span>
  );
});

/** Labeled metric cell used inside a server card. */
function Metric({ label, children }: { label: string; children: ReactNode }) {
  return (
    <div>
      <p className="mb-1 text-[10px] font-medium uppercase tracking-[0.14em] text-muted-foreground">
        {label}
      </p>
      <div className="font-mono text-sm font-semibold text-foreground">
        {children}
      </div>
    </div>
  );
}

/* ── STEP 6 · ServerCard ──────────────────────────────────────────────────── */
const ServerCard = memo(function ServerCard({
  server,
}: {
  server: ServerRecord;
}) {
  const online = isOnline(server.status);
  const isSuspended = server.suspended;

  const content = (
    <>
      {/* 6.1 · Status edge-light */}
      <div
        className={`pointer-events-none absolute inset-x-0 top-0 h-px ${
          online
            ? "bg-gradient-to-r from-transparent via-emerald-400/60 to-transparent"
            : "bg-gradient-to-r from-transparent via-white/15 to-transparent"
        }`}
      />
      {/* 6.2 · Lightweight Core echo: All Servers stays 2D for fast scanning */}
      <span className={`snx-core-echo snx-core-echo--${online ? "online" : isSuspended ? "offline" : "warning"}`} aria-hidden="true" />
      {/* 6.3 · Header */}
      <div className="flex items-start justify-between gap-4">
        <div className="flex min-w-0 items-center gap-3.5">
          <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl border border-border bg-muted text-muted-foreground transition-colors group-hover:border-border-strong group-hover:text-foreground">
            <Server className="h-6 w-6" />
          </div>
          <div className="min-w-0">
            <h2 className="truncate text-lg font-semibold tracking-tight text-foreground">
              {server.name}
            </h2>
            <div className="mt-1.5 flex items-center gap-2">
              <StatusBadge status={server.status} />
              {isSuspended && (
                <span className="inline-flex items-center gap-1 rounded-md border border-red-500/20 bg-red-500/10 px-2 py-0.5 text-[10px] font-semibold tracking-wide text-red-400 uppercase">
                  <Lock className="h-3 w-3" />
                  Suspended
                </span>
              )}
            </div>
          </div>
        </div>
        {!isSuspended && (
          <ChevronRight className="mt-1 h-5 w-5 shrink-0 text-muted-foreground transition-all group-hover:translate-x-0.5 group-hover:text-foreground-muted" />
        )}
      </div>
      {/* 6.3 · Identity and limits */}
      <div className="mt-5 grid grid-cols-2 gap-4 rounded-xl border border-border-subtle bg-muted px-4 py-4 sm:grid-cols-4">
        <Metric label="Owner"><span className="block truncate" title={server.ownerUsername || server.owner}>{server.ownerUsername || server.owner || "—"}</span></Metric>
        <Metric label="Node"><span className="block truncate" title={server.nodeName || server.nodeId}>{server.nodeName || server.nodeId || "—"}</span></Metric>
        <Metric label="Address"><span className="block truncate font-mono text-xs" title={server.address}>{server.address || "—"}</span></Metric>
        <Metric label="Software / Version"><span className="block truncate" title={`${server.software || "—"} ${server.version || ""}`}>{server.software || "—"}{server.version ? ` · ${server.version}` : ""}</span></Metric>
      </div>
      <div className="mt-3 rounded-xl border border-border-subtle bg-black/10 px-4 py-3">
        <ServerLiveStats serverId={server.id} limitRam={server.ram} limitCpu={server.cpu} limitDisk={server.disk} status={server.status} />
      </div>
    </>
  );

  return (
    <motion.article variants={itemVariants}>
      {isSuspended ? (
        <div className="group relative block overflow-hidden rounded-2xl border border-red-500/10 bg-black/40 dark:bg-black/40 p-5 opacity-75 md:p-6 cursor-not-allowed">
          {content}
        </div>
      ) : (
        <Link
          to={`/servers/${server.id}`}
          className="group relative block overflow-hidden rounded-2xl border border-border-subtle bg-muted-subtle p-5 transition-colors duration-200 hover:border-border-strong hover:bg-muted focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white/20 md:p-6"
        >
          {content}
        </Link>
      )}
    </motion.article>
  );
});

/* ── STEP 7 · Sections ────────────────────────────────────────────────────── */
function LoadingState() {
  return (
    <div
      className="flex min-h-[50vh] flex-col items-center justify-center gap-4"
      style={{ backgroundColor: SURFACE }}
    >
      <div
        className="h-10 w-10 animate-spin rounded-full border-2 border-border border-t-white/70"
        aria-hidden
      />
      <p className="text-sm font-medium text-muted-foreground">Loading instances…</p>
    </div>
  );
}

function EmptyState({ isAdmin }: { isAdmin: boolean }) {
  return (
    <motion.div
      variants={itemVariants}
      className="col-span-full flex flex-col items-center justify-center rounded-2xl border border-dashed border-border bg-muted-subtle px-6 py-24 text-center"
    >
      <div className="mb-5 flex h-14 w-14 items-center justify-center rounded-xl border border-border bg-muted">
        <Server className="h-6 w-6 text-muted-foreground" />
      </div>
      <h3 className="text-base font-semibold text-foreground">
        No instances running
      </h3>
      <p className="mt-1 max-w-sm text-sm text-muted-foreground">
        You haven&apos;t deployed any servers yet. Create one to start managing
        your game instances.
      </p>
      {isAdmin && (
        <Link
          to="/servers/create"
          className="mt-6 inline-flex h-10 items-center justify-center gap-2 rounded-lg bg-[var(--btn-primary-bg)] px-4 text-sm font-semibold text-[var(--btn-primary-text)] transition-colors hover:bg-zinc-200 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white/50 focus-visible:ring-offset-2 focus-visible:ring-offset-[#070708]"
        >
          <Plus className="h-4 w-4" />
          Deploy your first server
        </Link>
      )}
    </motion.div>
  );
}

/* ── STEP 8 · Page composition ────────────────────────────────────────────── */
export default function ServerList() {
  const { user } = useAuth();
  const { servers, error, isLoading } = useServers();

  // 8.1 · Gating — resolve auth BEFORE making any role decision.
  //        `user` is undefined while auth is still restoring; null when logged
  //        out; an object once resolved. Gating on this prevents admin controls
  //        from flickering in/out on first paint.
  //        If your AuthContext exposes an explicit flag instead (e.g. `loading`
  //        or `isReady`), swap the line below for: const isAuthReady = !loading;
  const isAuthReady = user !== undefined;
  const isAdmin = isAuthReady && (user?.role === "admin" || user?.role === "owner");
  const hasServers = servers.length > 0;

  // 8.2 · Live "X of Y online" summary.
  const onlineCount = useMemo(
    () => servers.reduce((n, s) => n + (isOnline(s.status) ? 1 : 0), 0),
    [servers],
  );

  // 8.3 · First paint: wait for auth readiness AND the initial data load.
  if (!isAuthReady || (isLoading && !hasServers)) return <LoadingState />;

  // 8.4 · Full page.
  return (
    <div
      className="relative min-h-screen text-foreground"
      style={{ backgroundColor: SURFACE }}
    >
      <div className="relative mx-auto max-w-7xl px-5 py-8 md:px-8 md:py-10">
        {/* 8.4a · Header */}
        <header className="mb-8 flex flex-col gap-4 border-b border-border-subtle pb-6 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <p className="mb-1 text-xs font-medium uppercase tracking-[0.14em] text-muted-foreground">
              Infrastructure
            </p>
            <h1 className="text-2xl font-semibold tracking-tight text-foreground">
              Instances
            </h1>
            <p className="mt-1 text-sm text-muted-foreground">
              {hasServers
                ? `${onlineCount} of ${servers.length} online · Manage and monitor your fleet.`
                : "Manage and monitor your server fleet."}
            </p>
          </div>
          {isAdmin && (
            <div className="flex gap-2">
              <Link
                to="/admin/servers"
                className="inline-flex h-10 items-center justify-center gap-2 rounded-lg bg-zinc-800 px-4 text-sm font-semibold text-foreground transition-colors hover:bg-zinc-700 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white/50 focus-visible:ring-offset-2 focus-visible:ring-offset-[#070708]"
              >
                <Settings className="h-4 w-4" />
                Manage
              </Link>
              <Link
                to="/servers/create"
                className="inline-flex h-10 items-center justify-center gap-2 rounded-lg bg-[var(--btn-primary-bg)] px-4 text-sm font-semibold text-[var(--btn-primary-text)] transition-colors hover:bg-zinc-200 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white/50 focus-visible:ring-offset-2 focus-visible:ring-offset-[#070708]"
              >
                <Plus className="h-4 w-4" />
                New Instance
              </Link>
            </div>
          )}
        </header>

        {/* 8.4b · Error banner */}
        {error && (
          <div
            role="alert"
            className="mb-6 rounded-xl border border-red-500/20 bg-red-500/[0.08] px-4 py-3 text-sm font-medium text-red-300"
          >
            {error}
          </div>
        )}

        {/* 8.4c · Fleet */}
        <motion.section
          variants={containerVariants}
          initial="hidden"
          animate="show"
          className="grid grid-cols-1 gap-4"
          aria-label="Server instances"
        >
          {hasServers ? (
            servers.map((server) => (
              <ServerCard key={server.id} server={server} />
            ))
          ) : (
            <EmptyState isAdmin={isAdmin} />
          )}
        </motion.section>
      </div>
    </div>
  );
}
