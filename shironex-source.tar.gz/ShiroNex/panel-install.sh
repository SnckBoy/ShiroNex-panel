#!/usr/bin/env bash
set -euo pipefail
APP_NAME="shironex-panel"; APP_DIR="${SHIRONEX_PANEL_DIR:-/opt/shironex-panel}"; PORT="${PORT:-6767}"
SOURCE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
log(){ printf '\033[1;36m[SHIRONEX]\033[0m %s\n' "$*"; }
fail(){ printf '\033[1;31m[ERROR]\033[0m %s\n' "$*"; exit 1; }
[[ $EUID -eq 0 ]] || fail "Run as root: sudo bash install.sh"
install_panel(){
 . /etc/os-release; [[ "$ID" == "ubuntu" || "$ID" == "debian" ]] || fail "This installer supports Ubuntu/Debian."
 apt-get update; apt-get install -y ca-certificates curl git build-essential
 if ! command -v node >/dev/null || [[ "$(node -p 'process.versions.node.split(".")[0]')" -lt 20 ]]; then curl -fsSL https://deb.nodesource.com/setup_22.x | bash -; apt-get install -y nodejs; fi
 install -d -m 750 "$APP_DIR"; rsync -a --delete --exclude dist --exclude node_modules "$SOURCE_DIR/" "$APP_DIR/" 2>/dev/null || cp -a "$SOURCE_DIR"/. "$APP_DIR/"
 cd "$APP_DIR"
 [[ -f .env ]] || cp .env.example .env
 if ! grep -q '^JWT_SECRET=' .env; then echo "JWT_SECRET=$(openssl rand -hex 32)" >> .env; fi
 if ! grep -q '^NODE_ENCRYPTION_KEY=' .env; then echo "NODE_ENCRYPTION_KEY=$(openssl rand -hex 32)" >> .env; fi
 npm install
 npm run build
 npm install -g pm2
 pm2 delete "$APP_NAME" >/dev/null 2>&1 || true
 PORT="$PORT" pm2 start ecosystem.config.cjs --name "$APP_NAME" --update-env
 pm2 save
 log "ShiroNex Panel installed at http://SERVER-IP:$PORT"
}
update_panel(){ cd "$APP_DIR"; npm install; npm run build; pm2 restart "$APP_NAME" --update-env; }
status_panel(){ pm2 status "$APP_NAME" || true; }
case "${1:-install}" in install) install_panel;; update) update_panel;; status) status_panel;; *) echo "Usage: sudo bash install.sh [install|update|status]";; esac
